#!/bin/bash

read -p "Enter the Date: (MMDD) " RDate
read -p "Enter the Time: (XX:00:00) " RTime
read -p "Enter AM/PM: " RAP

echo
grep -n "$RTime" "$RDate"_Dealer_schedule | grep -iw "$RAP" | awk '{print $1,$2," Table Operator : ",$5,$6}' >> Dealers_working_during_losses

#This code will allow the user to be able to search the Dealer schedules  and will append the name of the dealer you searched to the Dealers_working_during_losses file. 
